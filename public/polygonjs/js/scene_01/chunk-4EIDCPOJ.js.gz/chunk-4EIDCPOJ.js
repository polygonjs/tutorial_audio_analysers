var t={sceneData:{start:0,mult:.25},assets:{start:.25,mult:0},nodes:{start:.25,mult:.75}};export{t as a};
